// Paste the Web app URL from your Google Apps Script deployment between the quotes.
// It looks like https://script.google.com/macros/s/AKfycb.../exec
window.TRACKER_CONFIG = {
  api: "",
  // A tool out this many days shows in red.
  overdueDays: 7
};
