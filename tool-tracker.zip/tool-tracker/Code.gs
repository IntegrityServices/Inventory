/**
 * Tool Tracker: backend
 *
 * Paste this into Extensions > Apps Script in a Google Sheet, run setup() once,
 * then Deploy > New deployment > Web app (Execute as: Me, Who has access: Anyone).
 * The sheet only stores the data. Workers use the web page, never the sheet.
 */

const HEADERS = {
  Items: ['Code', 'Type', 'Name', 'Category', 'Status', 'Holder', 'HolderId', 'Site', 'Since', 'Qty', 'Min', 'Active'],
  People: ['Id', 'Name', 'Active'],
  Log: ['Time', 'Code', 'Item', 'Action', 'Person', 'Site', 'Qty', 'Note', 'Batch']
};
const IT = { CODE: 0, TYPE: 1, NAME: 2, CAT: 3, STATUS: 4, HOLDER: 5, HOLDER_ID: 6, SITE: 7, SINCE: 8, QTY: 9, MIN: 10, ACTIVE: 11 };

/** Run once. Creates the sheets and a random 6-digit PIN (see the Settings sheet). */
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(HEADERS).forEach(function (name) {
    const sh = ss.getSheetByName(name) || ss.insertSheet(name);
    const n = HEADERS[name].length;
    if (sh.getLastRow() === 0) sh.getRange(1, 1, 1, n).setValues([HEADERS[name]]);
    sh.getRange(1, 1, 1, n).setFontWeight('bold').setBackground('#e6edf2');
    sh.setFrozenRows(1);
  });
  // Codes stay text so barcodes with leading zeros survive.
  ss.getSheetByName('Items').getRange('A:A').setNumberFormat('@');
  ss.getSheetByName('People').getRange('A:A').setNumberFormat('@');
  ss.getSheetByName('Log').getRange('B:B').setNumberFormat('@');

  const st = ss.getSheetByName('Settings') || ss.insertSheet('Settings');
  if (st.getLastRow() === 0) {
    st.getRange('A1:B1').setValues([['Setting', 'Value']]).setFontWeight('bold');
    st.getRange('B2').setNumberFormat('@');
    st.getRange('A2:B2').setValues([['PIN', String(Math.floor(100000 + Math.random() * 900000))]]);
    st.getRange('A4').setValue('Workers type this PIN once on their phone. Change it any time by editing cell B2.');
  }
  const blank = ss.getSheetByName('Sheet1');
  if (blank && blank.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(blank);
  Logger.log('Setup done. Your PIN is ' + getPin_());
}

// ---------- web entry points ----------

function doGet(e) {
  return handle_(e && e.parameter ? e.parameter : {});
}

function doPost(e) {
  var req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'Bad request' }); }
  return handle_(req);
}

function handle_(req) {
  if (String(req.pin || '') !== getPin_()) return json_({ ok: false, error: 'pin' });
  try {
    var out;
    switch (req.action) {
      case 'state': out = { ok: true }; break;
      case 'batch': out = applyBatch_(req); break;
      case 'addItems': out = addItems_(req); break;
      case 'addPerson': out = addPerson_(req); break;
      case 'updateItem': out = updateItem_(req); break;
      default: return json_({ ok: false, error: 'Unknown action' });
    }
    out.state = getState_();
    return json_(out);
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function getPin_() {
  var st = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Settings');
  return st ? String(st.getRange('B2').getValue()).trim() : '';
}

// ---------- reading ----------

function sheet_(name) { return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name); }

function readRows_(name) {
  var sh = sheet_(name), last = sh.getLastRow();
  return last > 1 ? sh.getRange(2, 1, last - 1, HEADERS[name].length).getValues() : [];
}

function iso_(v) { return v instanceof Date ? v.toISOString() : (v ? String(v) : ''); }

function itemToJson_(r) {
  return {
    code: String(r[IT.CODE]), type: r[IT.TYPE], name: r[IT.NAME], category: r[IT.CAT],
    status: r[IT.STATUS], holder: r[IT.HOLDER], holderId: String(r[IT.HOLDER_ID] || ''),
    site: r[IT.SITE], since: iso_(r[IT.SINCE]),
    qty: r[IT.QTY] === '' ? null : Number(r[IT.QTY]), min: r[IT.MIN] === '' ? null : Number(r[IT.MIN])
  };
}

function getState_() {
  var items = readRows_('Items').filter(function (r) { return r[IT.ACTIVE] !== 'No' && r[IT.CODE] !== ''; }).map(itemToJson_);
  var people = readPeople_().map(function (p) { return { id: p.id, name: p.name }; });
  var sh = sheet_('Log'), last = sh.getLastRow(), log = [];
  if (last > 1) {
    var first = Math.max(2, last - 299);
    log = sh.getRange(first, 1, last - first + 1, HEADERS.Log.length).getValues().reverse().map(function (r) {
      return { time: iso_(r[0]), code: String(r[1]), item: r[2], action: r[3], person: r[4], site: r[5], qty: r[6], note: r[7] };
    });
  }
  return { items: items, people: people, log: log, serverTime: new Date().toISOString() };
}

function readPeople_() {
  return readRows_('People').filter(function (r) { return r[2] !== 'No' && r[0] !== ''; })
    .map(function (r) { return { id: String(r[0]), name: String(r[1]) }; });
}

// ---------- writing ----------

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function appendLog_(rows) {
  if (!rows.length) return;
  var sh = sheet_('Log');
  sh.getRange(sh.getLastRow() + 1, 1, rows.length, HEADERS.Log.length).setValues(rows);
}

function nextCode_(prefix, taken) {
  var max = 0, re = new RegExp('^' + prefix + '(\\d+)$');
  Object.keys(taken).forEach(function (c) { var m = re.exec(c); if (m) max = Math.max(max, Number(m[1])); });
  var n = max + 1, code = prefix + ('0000' + n).slice(-4);
  taken[code] = true;
  return code;
}

function applyBatch_(req) {
  return withLock_(function () {
    var cache = CacheService.getScriptCache();
    if (req.batchId) {
      var prior = cache.get('b_' + req.batchId);
      if (prior) return JSON.parse(prior);   // a retry of a batch that already went through
    }
    var people = readPeople_();
    var person = null;
    people.forEach(function (p) { if (p.id === req.personId) person = p; });
    var who = person ? person.name : '';

    var sh = sheet_('Items'), rows = readRows_('Items'), index = {};
    rows.forEach(function (r, i) { index[String(r[IT.CODE]).toUpperCase()] = i; });

    var now = new Date(), touched = {}, logRows = [], results = [];
    (req.ops || []).forEach(function (op) {
      var i = index[String(op.code || '').toUpperCase()];
      if (i === undefined || rows[i][IT.ACTIVE] === 'No') { results.push({ code: op.code, ok: false, msg: 'Not in the list' }); return; }
      var r = rows[i], code = String(r[IT.CODE]), name = r[IT.NAME];

      if (r[IT.TYPE] === 'Tool') {
        if (op.action === 'out') {
          if (!person) { results.push({ code: code, name: name, ok: false, msg: 'No name chosen' }); return; }
          var wasOut = r[IT.STATUS] === 'Out';
          if (wasOut && String(r[IT.HOLDER_ID]) === person.id) { results.push({ code: code, name: name, ok: true, action: 'NOCHANGE', msg: 'Already with ' + who }); return; }
          var from = wasOut ? 'From ' + r[IT.HOLDER] : '';
          r[IT.STATUS] = 'Out'; r[IT.HOLDER] = who; r[IT.HOLDER_ID] = person.id; r[IT.SITE] = op.site || ''; r[IT.SINCE] = now;
          touched[i] = true;
          logRows.push([now, code, name, wasOut ? 'TRANSFER' : 'OUT', who, op.site || '', '', from, req.batchId || '']);
          results.push({ code: code, name: name, ok: true, action: wasOut ? 'TRANSFER' : 'OUT' });
        } else {
          if (r[IT.STATUS] !== 'Out') { results.push({ code: code, name: name, ok: true, action: 'NOCHANGE', msg: 'Already in the shop' }); return; }
          var was = r[IT.HOLDER];
          r[IT.STATUS] = 'In'; r[IT.HOLDER] = ''; r[IT.HOLDER_ID] = ''; r[IT.SITE] = ''; r[IT.SINCE] = now;
          touched[i] = true;
          logRows.push([now, code, name, 'IN', who || was, '', '', was && who && was !== who ? 'Was with ' + was : '', req.batchId || '']);
          results.push({ code: code, name: name, ok: true, action: 'IN' });
        }
      } else {
        var cur = Number(r[IT.QTY]) || 0, delta = Number(op.delta) || 0;
        if (!delta) { results.push({ code: code, name: name, ok: true, action: 'NOCHANGE' }); return; }
        var next = cur + delta, note = '';
        if (next < 0) { note = 'Only ' + cur + ' on hand'; next = 0; }
        r[IT.QTY] = next; touched[i] = true;
        logRows.push([now, code, name, delta < 0 ? 'TAKE' : 'RESTOCK', who, op.site || '', Math.abs(next - cur), note, req.batchId || '']);
        results.push({ code: code, name: name, ok: true, action: delta < 0 ? 'TAKE' : 'RESTOCK', qty: Math.abs(next - cur), msg: note });
      }
    });

    Object.keys(touched).forEach(function (i) {
      sh.getRange(Number(i) + 2, 1, 1, HEADERS.Items.length).setValues([rows[i]]);
    });
    appendLog_(logRows);
    var out = { ok: true, results: results };
    if (req.batchId) cache.put('b_' + req.batchId, JSON.stringify(out), 21600);
    return out;
  });
}

function addItems_(req) {
  return withLock_(function () {
    var sh = sheet_('Items'), rows = readRows_('Items'), taken = {}, added = [], now = new Date(), logRows = [];
    rows.forEach(function (r) { taken[String(r[IT.CODE]).toUpperCase()] = true; });
    (req.items || []).forEach(function (it) {
      var name = String(it.name || '').trim();
      if (!name) return;
      var type = it.type === 'Material' ? 'Material' : 'Tool';
      var code = String(it.code || '').trim();
      if (code) {
        if (taken[code.toUpperCase()]) return;
        taken[code.toUpperCase()] = true;
      } else {
        code = nextCode_(type === 'Tool' ? 'T' : 'M', taken);
      }
      var row = [code, type, name, String(it.category || '').trim(), type === 'Tool' ? 'In' : '', '', '', '', now,
        type === 'Material' ? (Number(it.qty) || 0) : '', type === 'Material' && it.min !== '' && it.min != null ? Number(it.min) : '', 'Yes'];
      sh.getRange(sh.getLastRow() + 1, 1, 1, row.length).setValues([row]);
      logRows.push([now, code, name, 'ADD', '', '', type === 'Material' ? row[IT.QTY] : '', '', '']);
      added.push({ code: code, name: name, type: type });
    });
    appendLog_(logRows);
    return { ok: true, added: added };
  });
}

function addPerson_(req) {
  return withLock_(function () {
    var name = String(req.name || '').trim();
    if (!name) return { ok: false, error: 'Enter a name' };
    var people = readPeople_(), existing = null;
    people.forEach(function (p) { if (p.name.toLowerCase() === name.toLowerCase()) existing = p; });
    if (existing) return { ok: true, person: existing };
    var taken = {};
    readRows_('People').forEach(function (r) { taken[String(r[0])] = true; });
    var id = nextCode_('P', taken), sh = sheet_('People');
    sh.getRange(sh.getLastRow() + 1, 1, 1, 3).setValues([[id, name, 'Yes']]);
    return { ok: true, person: { id: id, name: name } };
  });
}

function updateItem_(req) {
  return withLock_(function () {
    var sh = sheet_('Items'), rows = readRows_('Items'), f = req.fields || {};
    for (var i = 0; i < rows.length; i++) {
      if (String(rows[i][IT.CODE]).toUpperCase() !== String(req.code).toUpperCase()) continue;
      var r = rows[i];
      if (f.name != null && String(f.name).trim()) r[IT.NAME] = String(f.name).trim();
      if (f.category != null) r[IT.CAT] = String(f.category).trim();
      if (f.min !== undefined && r[IT.TYPE] === 'Material') r[IT.MIN] = f.min === '' || f.min === null ? '' : Number(f.min);
      if (f.active === false) r[IT.ACTIVE] = 'No';
      sh.getRange(i + 2, 1, 1, HEADERS.Items.length).setValues([r]);
      appendLog_([[new Date(), r[IT.CODE], r[IT.NAME], f.active === false ? 'RETIRE' : 'EDIT', '', '', '', '', '']]);
      return { ok: true };
    }
    return { ok: false, error: 'Not in the list' };
  });
}
