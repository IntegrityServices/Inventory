# Tool Tracker: one-time setup (about 15 minutes)

You need a free Google account and a free GitHub account. Workers need neither. They open a link and type a PIN once.

How it fits together:

- **Google Sheet** stores the data (you can open it any time to see everything).
- **Google Apps Script** (`Code.gs`) lets the web page read and write that sheet.
- **The web page** (`index.html`) is what everyone uses. It is hosted free on GitHub Pages.

## 1. Make the Google Sheet and script

1. Go to https://sheets.new and name the sheet "Tool Tracker".
2. Open **Extensions > Apps Script**. Delete the placeholder code, paste in everything from `Code.gs`, and click Save.
3. In the function dropdown at the top, choose `setup` and click **Run**. Google asks you to authorize it. Click Advanced, then "Go to (project name)", then Allow. This is normal for your own scripts.
4. Go back to the sheet. There are new tabs. Open **Settings**: the team **PIN** is in cell B2. You can change it to anything you like.
5. In Apps Script click **Deploy > New deployment**. Click the gear icon and pick **Web app**. Set:
   - Execute as: **Me**
   - Who has access: **Anyone**
6. Click Deploy and copy the **Web app URL** (it ends in `/exec`).

If you edit `Code.gs` later, use Deploy > Manage deployments > edit > New version, or your changes will not go live.

## 2. Connect the page to the script

Open `config.js` in any text editor and paste the Web app URL between the quotes after `api:`. Save it.

## 3. Put the page online

1. Create a GitHub repository (public, any name).
2. Upload `index.html`, `config.js`, and the `lib` folder (with `jsQR.js` and `qrcode.js` inside).
3. In the repository go to **Settings > Pages**. Under "Build and deployment" choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and Save.
4. After a minute GitHub shows your page address, like `https://yourname.github.io/toolbox/`.

The page code is public but holds no data. Without the PIN nobody can read or change your inventory. Any other free static host also works.

## 4. First run

1. Open the page address on your phone or computer and enter the PIN.
2. Pick or add your name.
3. **Setup > Add tools and materials**: type or paste a list, one per line.
4. **Setup > Print the ones you just added**, print at 100% size, and stick one label on each tool and bin.
5. Send your crew the page address and the PIN. On a phone, use Share > Add to Home Screen so it is one tap away.

## Everyday use

**In the field:** open the page, tap Start camera, point it at each tool's QR label, then press **Confirm**. The page works out whether each tool is being checked out or returned. Tap the green or blue button on a row to flip it. A tool that was never checked out at the shop shows "In the shop", and Confirm checks it out to you.

**At the shop with the Zebra DS8178:** keep the page open on the computer and scan. The scanner types the code and presses Enter, and the tool lands in the list. Press Confirm, or scan the **SEND** label (Setup > Print Send and Clear codes). Scanning a name badge switches who the tools go to. Turn on "Shared computer" in Setup so it asks for a name after each Confirm.

**Materials:** scan the bin label. Scan again to add one more, use the + and - buttons for bigger counts, and flip Take / Add to restock. Set a "reorder at" number and low items turn red.

**No signal:** Confirm still works. It saves on the phone and sends by itself when the phone is back online.

**Tools you already have barcodes on:** scan one, tap "Add it", and give it a name. That barcode becomes the tool's code.

## Things to know

- The PIN is light protection. Anyone with the page address and PIN can see and change records, so share it only with your crew, and change it in the Settings tab if someone leaves.
- Phones need https to use the camera. GitHub Pages provides that.
- If the page says the Google script is not answering correctly, re-check step 1.5: access must be "Anyone".
- Every change is logged in the Log tab of the sheet. Retired items are only hidden, never deleted.
